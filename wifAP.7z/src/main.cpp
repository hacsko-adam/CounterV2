#include <Arduino.h>
#include <ESP8266WiFi.h> 
#include <ESP8266WebServer.h>
#include <SPI.h>

#include "LedMatrix.h"
#define NUMBER_OF_DEVICES 4 //number of led matrix connect in series
#define CS_PIN D2
#define touchPin D0

LedMatrix ledMatrix = LedMatrix(NUMBER_OF_DEVICES, CS_PIN);

const char* ssid = "TADEV Counter";
const char* pass ="newenglandikagyloleves";
ESP8266WebServer server(80);


byte data[] = {
  0x0,0x2,0x2,0x3E,0x2,0x2,0x20,0x18,0x16,0x16,0x18,0x20,0x0,0x3E,0x22,0x22,0x1C,0x0,0x3E,0x2A,0x2A,0x22,0x0,0x2,0xE,0x18,0x20,0x20,0x18,0xE,0x2,0x0
};

bool IsBitSet(uint8_t num, int bit)
{
    return 1 == ( (num >> bit) & 1);
}

void handleRoot() {
  String body = "<!DOCTYPE html>"\
				"<html>"\
				"<head>"\
					"<title>LedMatrix</title>"\
					"<style>.demo{border:1px solid #C0C0C0;border-collapse:collapse;padding:5px;}.demo th{border:1px solid #C0C0C0;background:#F0F0F0;}.demo td{border:1px solid #C0C0C0;width:20px;height:20px;}.red{background-color:red;}thead>tr>:nth-child(8n+1):not(:nth-child(1)),tbody>tr>:nth-child(8n+1):not(:nth-child(1)){border-left: solid 2px black;}</style>"\
				"</head>"\
				"<body>"\
					"<table class='demo'>"\
					"<caption>Write it yourself</caption>"\
					"<thead>"\
					"<tr>";
  for(int i = 0; i < 32; i++){
    body += "<th>";
    body += i;
    body += "</th>";
  }
  body +="</tr>"\
					 "</thead>"\
					 "<tbody>";
  for(int i = 0; i < 8; i++){
    body += "<tr>";
    for(int j = 0; j < 32; j++){
      if(IsBitSet(data[j], i)){
        body += "<td class='red'>&nbsp;</td>";
      }
      else{
        body += "<td>&nbsp;</td>";
      }
    }
    body += "</tr>";
  }

  body +=	"</tbody>"\
					"</table>"\
          "<a class='sendIt' href='#' >Send it!</a>"\
          "<script type='text/javascript'>"\
            "function toggleClass(e,t){var n,l=e.className;n=l.split(' ').indexOf(t)>-1?l.replace(t,''):l+' '+t,e.className=n.trim()}function hasClass(e,t){return e.className.split(' ').indexOf(t)>-1}var inputs=document.querySelectorAll('.demo tbody td');for(i=0;i<inputs.length;i++)inputs[i].addEventListener('click',function(){toggleClass(this,'red'),updateLink()});function updateLink(){let e='/draw?data=';for(let t=1;t<33;t++){let n='';for(let e=8;e>0;e--)hasClass(getCell(e,t),'red')?n+=1:n+=0;e+=parseInt(n,2).toString(16).toUpperCase()+','}e=e.slice(0,-1),document.querySelector('.sendIt').href=e,httpGet(e)}function getCell(e,t){return document.querySelector('.demo tbody tr:nth-child('+e+') td:nth-child('+t+')')}function httpGet(e){var t=new XMLHttpRequest;return t.open('GET',e,!1),t.send(null),t.responseText}"\
          "</script>"\
					"</body>"\
				"</html>";


  server.send(200, "text/html", body);
}

void parse(String input){
  size_t pos = 0;
  int found = 0;
  char delimiter = ',';

  for(int i = 1; i < input.length(); i++)
  {
    if(input[i] == delimiter){
      data[found] = strtoull(input.substring(pos, i).c_str(), NULL, 16);
      pos = i+1;
      found++;
    }
  }
  
}

void handleDraw() {
  String a = server.arg("data");
  parse(a);

  

  ledMatrix.drawArray(data);
  ledMatrix.commit();
  handleRoot();
}

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  delay(10);
  Serial.println('\n');

  WiFi.softAP(ssid, pass);
  Serial.print("Access Point \"");
  Serial.print(ssid);
  Serial.println("\" started");

  Serial.print("IP address:\t");
  Serial.println(WiFi.softAPIP());    
  
  server.on("/", handleRoot);
  server.on("/draw", handleDraw);
  server.begin();
  
  ledMatrix.init();    
  ledMatrix.drawArray(data);
  ledMatrix.commit();
  //pinMode(touchPin, INPUT);
}

void loop() {
  server.handleClient();
    
   // ledMatrix.scrollTextRight();
    //ledMatrix.drawText();

    //ledMatrix.drawArray(data);
    //ledMatrix.commit();
    
    /*int touchValue = digitalRead(touchPin);
    if (touchValue == HIGH)
    {
      Serial.println("TOUCHED");
    }*/
}